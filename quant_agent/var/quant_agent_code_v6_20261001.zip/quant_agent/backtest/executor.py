#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""执行层现金账户模拟器（2026-09-30 评审后新增，P0）。

职责边界（不改写策略，符合方案文档"先接入原模型"纪律）：
  - qengine.run_r443 仍是信号/订单生成器（权重口径），保持冻结；
  - 本模块把引擎产出的"意图订单"在确定性现金账户里执行：
      · 名义额 = 目标权重 w × 当日开盘权益，三者取最小：
        目标额 / 敞口上限剩余额度 / 可用现金÷(1+买费)；
      · 整手（100 股）向下取整，不足一手放弃（记录在案）；
      · 费用从现金扣除（买费入成本、卖费扣 Proceeds）；
      · 出场日/顺延规则沿用引擎产出（引擎已处理停牌/跌停顺延）；
      · 禁止融券：名义额永不超过现金与敞口上限。
  - 产出与引擎 run 输出同构（trades/daily/exposure/...），
    metrics 复用 qengine.metrics，可直接进 Gate。

局限（如实声明）：
  - 部分成交未建模（整手粒度即最小成交单位假设）；
  - 开盘价集合竞价滑点未建模（沿用引擎 open 成交假设）；
  - 权重的 H=5 分仓语义由引擎保留，执行层只负责"买得起、不超仓"。
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(
    os.path.dirname(os.path.abspath(__file__)))))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(
    os.path.dirname(os.path.abspath(__file__)))), "qsys"))


def _fee(notional, rate, min_fee):
    """完整费用模型（评审第 3 轮）: 比例费率与最低收费取大，支持取整边界。

    纯比例费下 cash/(1+r) 闭式解足够；存在最低收费/固定费用时，
    金额上界 (cash-min_fee)/px 才是约束——两种情形取较小上界，
    再逐手回验，覆盖小额订单、最低收费边界、多笔批次与舍入。
    """
    if notional <= 0:
        return 0.0
    return max(notional * rate, min_fee)


def _max_affordable_shares(px, cash, rate, min_fee, lot=100):
    if px <= 0 or cash <= 0:
        return 0
    bound = min(cash / (px * (1.0 + rate)),
                max(cash - min_fee, 0.0) / px)
    shares = int(bound / lot) * lot
    while shares > 0:
        notional = shares * px
        if notional + _fee(notional, rate, min_fee) <= cash + 1e-9:
            return shares
        shares -= lot
    return 0


def _band_of(code):
    return 0.195 if code.startswith(("688", "300", "301")) else 0.095


def execute_cash(intended, stocks, common, susp, cost_buy, cost_sell,
                 cap=1.0, cash0=1_000_000.0, lot=100, end_day=None,
                 min_fee_buy=5.0, min_fee_sell=5.0,
                 check_limit_at_fill=True):
    """intended: qengine.run_r443 的 trades 列表（已按 e 升序）。

    返回与引擎输出同构的 dict；trades 附 shares/fee_buy/fee_sell/
    notional/skip 原因（skipped_entries 另列）。

    同代码多笔重叠持仓按独立批次处理（引擎权重口径允许连续日
    对同一标的加仓；现金账户以独立 lot 批次实现同等语义）。
    """
    entries_by_day = {}
    for tr in intended:
        entries_by_day.setdefault(tr["e"], []).append(tr)

    cash = cash0
    positions = {}           # pid -> dict(shares, entry_px, e, xe, code,...)
    trades = []
    skipped = []             # 资金/上限不足而放弃的意图
    daily_exposure = {}
    daily_equity = {}        # 开盘口径权益（开盘成交后、开盘价估值）
    daily_cash = {}          # 当日全部开盘后流水完成后的现金
    entry_days = set()
    daily_traded = {}
    total_cost = 0.0

    n = len(common)
    if end_day is None:
        end_day = n - 1
    day0 = min(entries_by_day) if entries_by_day else 0
    pending_exits = {}       # day -> [pid,...]
    seq = 0

    for d in range(day0, end_day + 1):
        # 1) 开盘卖出（沿用引擎给出的出场日 xd）
        for pid in pending_exits.pop(d, []):
            pos = positions.pop(pid, None)
            if pos is None:
                continue
            code = pos["code"]
            o = stocks[code]["open"]
            if common[d] in susp.get(code, ()):
                # 引擎已顺延，理论上到不了这里；防御性顺延一日
                pending_exits.setdefault(d + 1, []).append(pid)
                positions[pid] = pos
                continue
            px = o[d]
            gross = pos["shares"] * px
            fee = _fee(gross, cost_sell, min_fee_sell)
            cash += gross - fee
            total_cost += fee
            daily_traded[d] = daily_traded.get(d, 0.0) + gross
            pos["exit_px"] = px
            pos["fee_sell"] = fee
            pos["exit_date"] = common[d]
            trades.append(pos)

        # 2) 开盘估值权益
        pos_val = 0.0
        for pid, pos in positions.items():
            pos_val += pos["shares"] * stocks[pos["code"]]["open"][d]
        equity = cash + pos_val
        daily_equity[d] = equity

        # 3) 开盘买入（信号日为 d-1 的订单）
        for tr in entries_by_day.get(d, []):
            code = tr["code"]
            o = stocks[code]["open"]
            if common[d] in susp.get(code, ()):
                skipped.append({"code": code, "e": d, "why": "suspended"})
                continue
            px = o[d]
            # 执行层复核涨停（评审第 3 轮）: 意图生成器的过滤是事前
            # 近似，成交时点必须重检开盘 vs 前收。可用 check_limit_at_fill
            # 独立关闭（归因消融实验用）。
            if check_limit_at_fill:
                prev_close = stocks[code]["close"][d - 1]
                band = _band_of(code)
                if px >= prev_close * (1.0 + band - 0.005):
                    skipped.append({"code": code, "e": d,
                                    "why": "limit_up_at_fill"})
                    continue
            target = tr["w"] * equity
            room = max(0.0, cap * equity - pos_val)
            # 最大合法数量: 成交金额 + 完整费用 ≤ 可用现金
            afford_shares = _max_affordable_shares(px, cash, cost_buy,
                                                   min_fee_buy, lot)
            target_shares = int(min(target, room) / (px * lot)) * lot
            shares = min(target_shares, afford_shares)
            if shares <= 0:
                skipped.append({"code": code, "e": d,
                                "why": "cash_or_cap",
                                "target": round(target, 2),
                                "room": round(room, 2),
                                "afford_shares": afford_shares})
                continue
            pay = shares * px
            fee = _fee(pay, cost_buy, min_fee_buy)
            assert pay + fee <= cash + 1e-6, "现金账户负现金（费用模型漏洞）"
            cash -= pay + fee
            total_cost += fee
            daily_traded[d] = daily_traded.get(d, 0.0) + pay
            pos_val += pay
            seq += 1
            pid = (code, d, seq)
            positions[pid] = {
                "code": code, "e": d, "xe": tr["xe"],
                "planned_reason": tr.get("planned_reason"),
                "reason": tr.get("reason"),
                "hold_days": None, "deferred_days": tr.get("deferred_days"),
                "entry_px": px, "entry_date": common[d],
                "shares": shares, "notional": pay, "fee_buy": fee,
                "w": tr["w"], "gross": None, "net": None,
                "suspended_entry": False,
            }
            pending_exits.setdefault(tr["xe"], []).append(pid)

        if positions:
            daily_exposure[d] = pos_val / max(equity, 1e-12)
        daily_cash[d] = cash
        if entries_by_day.get(d):
            entry_days.add(d)

    # 窗口末尾未平仓：按最后开盘估值强制平仓（不可带入未来）
    if positions and end_day >= day0:
        d = end_day
        for pid, pos in list(positions.items()):
            code = pos["code"]
            px = stocks[code]["open"][d]
            gross = pos["shares"] * px
            fee = _fee(gross, cost_sell, min_fee_sell)
            cash += gross - fee
            total_cost += fee
            pos["exit_px"] = px
            pos["fee_sell"] = fee
            pos["exit_date"] = common[d]
            pos["reason"] = (pos.get("reason") or "time") + "+window_cut"
            trades.append(pos)

    # 4) 日收益序列（开盘-开盘，费用内含；仅覆盖 [day0, end_day]）
    daily = []
    prev = cash0
    for d in range(day0, end_day + 1):
        eq = daily_equity.get(d)
        if eq is None:
            eq = prev
        daily.append(eq / prev - 1.0 if prev > 0 else 0.0)
        prev = eq

    idx = {d: i for i, d in enumerate(common)}
    for tr in trades:
        tr["gross"] = tr["exit_px"] / tr["entry_px"] - 1.0
        tr["net"] = (tr["gross"] - cost_buy - cost_sell)
        tr["hold_days"] = idx.get(tr["exit_date"], 0) - \
            idx.get(tr["entry_date"], 0)
        tr["w"] = tr["notional"] / cash0  # 实际权重（对初始资金）

    n_days = max(1, len(daily_exposure))
    avg_exp = ((sum(daily_exposure.values()) / len(daily_exposure))
               if daily_exposure else 0.0)
    denom = avg_exp * n_days
    turnover = (sum(daily_traded.values()) /
                (denom * cash0)) if denom > 0 else 0.0
    # 敞口上限语义（评审澄清）: 仅下单时约束，非每日强制再平衡。
    # 价格漂移可使市值敞口越上限——如实记录越限天数（当日无任何买入）。
    breach = sorted(d for d, v in daily_exposure.items()
                    if v > cap + 0.01 and d not in entry_days)
    return {"trades": trades, "daily": daily,
            "exposure": daily_exposure,
            "avg_exposure": avg_exp,
            "turnover": turnover, "total_cost": total_cost,
            "cash": cash, "skipped_entries": skipped,
            "cash0": cash0, "cap": cap,
            "daily_cash": daily_cash,
            "exposure_breach_days": breach}


if __name__ == "__main__":
    # 冒烟：用基线意图单在现金账户执行，验证无负现金、敞口≤上限
    from quant_agent.experiments.store import Store
    from quant_agent.backtest.runner import Context, BacktestRunner
    from quant_agent.strategies.adapter import normalize, materialize
    import quant_agent
    store = Store(os.path.join(quant_agent.VAR, "qa_store.sqlite3"))
    import json as _json
    const = _json.load(open(quant_agent.CONFIG))
    ctx = Context(constitution=const, use_universe=False)
    norm = normalize({}, const)
    spec, kw, _c = materialize(norm, ctx.stocks, ctx.codes, ctx.common)
    import qengine
    er = const["execution_rules"]
    isr = ctx.windows["IS"]
    run = qengine.run_r443(
        ctx.stocks, ctx.codes, ctx.feat, ctx.state, ctx.common, ctx.susp,
        isr[0], isr[1], isr[2], spec,
        cost_buy=er["cost_buy"], cost_sell=er["cost_sell"])
    ex = execute_cash(run["trades"], ctx.stocks, ctx.common, ctx.susp,
                      er["cost_buy"], er["cost_sell"], cap=1.0,
                      end_day=isr[2])
    m = qengine.metrics(ex)
    print("smoke: trades=%d skipped=%d final_cash=%.0f "
          "avg_exp=%.3f max_exp=%.3f ann=%.3f mdd=%.3f" % (
              len(ex["trades"]), len(ex["skipped_entries"]), ex["cash"],
              ex["avg_exposure"],
              max(ex["exposure"].values()) if ex["exposure"] else 0.0,
              m["annual_return"], m["max_drawdown"]))
